Service New Brunswick - GeoNB
http://www.snb.ca/geonb

**DESCRIPTION**
Municipal polygons are a graphical representation of the Municipal boundaries as defined in the Municipalities Regulation - Municipalities Act and have an associated place name attribute.

**FORMAT**
ESRI Shape File

**FILE LISTING**
geonb_municipalareas-zonesmunicipales.* - graphics and attributes

**SPATIAL FRAMEWORK**
Datum: North American Datum 1983 (CSRS)
Map Projection: NB Stereographic Double 
EPSG code: 2953

**SOURCE**
Department of Environment and Local Government

**DATE**
2020-09-02

**LICENSE**
Open Government Licence
http://www.snb.ca/e/2000/data-E.html
